/****************************************************************************
** Meta object code from reading C++ file 'imagelistmodel.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../imagelistmodel.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'imagelistmodel.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ImageListModel_t {
    QByteArrayData data[17];
    char stringdata0[164];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ImageListModel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ImageListModel_t qt_meta_stringdata_ImageListModel = {
    {
QT_MOC_LITERAL(0, 0, 14), // "ImageListModel"
QT_MOC_LITERAL(1, 15, 14), // "makeViewChange"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 12), // "countChanged"
QT_MOC_LITERAL(4, 44, 11), // "pickingFile"
QT_MOC_LITERAL(5, 56, 10), // "appendPics"
QT_MOC_LITERAL(6, 67, 4), // "path"
QT_MOC_LITERAL(7, 72, 18), // "emitMakeViewChange"
QT_MOC_LITERAL(8, 91, 5), // "count"
QT_MOC_LITERAL(9, 97, 3), // "get"
QT_MOC_LITERAL(10, 101, 5), // "index"
QT_MOC_LITERAL(11, 107, 4), // "role"
QT_MOC_LITERAL(12, 112, 4), // "data"
QT_MOC_LITERAL(13, 117, 13), // "DataForModel*"
QT_MOC_LITERAL(14, 131, 8), // "DataType"
QT_MOC_LITERAL(15, 140, 10), // "SourceRole"
QT_MOC_LITERAL(16, 151, 12) // "FilePathRole"

    },
    "ImageListModel\0makeViewChange\0\0"
    "countChanged\0pickingFile\0appendPics\0"
    "path\0emitMakeViewChange\0count\0get\0"
    "index\0role\0data\0DataForModel*\0DataType\0"
    "SourceRole\0FilePathRole"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ImageListModel[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       2,   62, // properties
       1,   70, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   49,    2, 0x06 /* Public */,
       3,    0,   50,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,   51,    2, 0x0a /* Public */,
       5,    1,   52,    2, 0x0a /* Public */,
       7,    0,   55,    2, 0x0a /* Public */,

 // methods: name, argc, parameters, tag, flags
       8,    0,   56,    2, 0x02 /* Public */,
       9,    2,   57,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void,

 // methods: parameters
    QMetaType::Int,
    QMetaType::QString, QMetaType::Int, QMetaType::Int,   10,   11,

 // properties: name, type, flags
      12, 0x80000000 | 13, 0x0009510b,
       8, QMetaType::Int, 0x00495103,

 // properties: notify_signal_id
       0,
       1,

 // enums: name, alias, flags, count, data
      14,   14, 0x0,    2,   75,

 // enum data: key, value
      15, uint(ImageListModel::SourceRole),
      16, uint(ImageListModel::FilePathRole),

       0        // eod
};

void ImageListModel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ImageListModel *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->makeViewChange(); break;
        case 1: _t->countChanged(); break;
        case 2: _t->pickingFile(); break;
        case 3: _t->appendPics((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: _t->emitMakeViewChange(); break;
        case 5: { int _r = _t->count();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 6: { QString _r = _t->get((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (ImageListModel::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ImageListModel::makeViewChange)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (ImageListModel::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ImageListModel::countChanged)) {
                *result = 1;
                return;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DataForModel* >(); break;
        }
    }

#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<ImageListModel *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< DataForModel**>(_v) = _t->data(); break;
        case 1: *reinterpret_cast< int*>(_v) = _t->count(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<ImageListModel *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setData(*reinterpret_cast< DataForModel**>(_v)); break;
        case 1: _t->setCount(*reinterpret_cast< int*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject ImageListModel::staticMetaObject = { {
    QMetaObject::SuperData::link<QAbstractListModel::staticMetaObject>(),
    qt_meta_stringdata_ImageListModel.data,
    qt_meta_data_ImageListModel,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *ImageListModel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ImageListModel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ImageListModel.stringdata0))
        return static_cast<void*>(this);
    return QAbstractListModel::qt_metacast(_clname);
}

int ImageListModel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QAbstractListModel::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 2;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void ImageListModel::makeViewChange()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void ImageListModel::countChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
