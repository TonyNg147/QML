#ifndef DATAFORMODEL_H
#define DATAFORMODEL_H
// this class is used as DataSource for our custom ImageListModel
#include <QObject>
struct DataItem{
    QString source;
    QString filePath;
};
class DataForModel : public QObject
{
    Q_OBJECT
public:

    explicit DataForModel(QObject *parent = nullptr);
    // return the Data Item
    QVector<DataItem> items() const;
    // return the result of setting data at given index
    bool setItemAt(int index, const DataItem& item);
public slots:
    // These slots will be called in QML to add and remove Item from DataSource
    void removeItem(int index);
    void appendItem(QString source, QString filePath);
signals:
    // These signals were built to alert the model about changes
    void preRemoveItem(int index);
    void postRemoveItem();
    void preAppendItem();
    void postAppendItem();
private:
    QVector<DataItem> m_item;
};

#endif // DATAFORMODEL_H
