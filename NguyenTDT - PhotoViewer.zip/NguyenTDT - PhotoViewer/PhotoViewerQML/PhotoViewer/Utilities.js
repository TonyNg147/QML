function maximizeImage(img,text,index)
{
    stackView.pop()
    stackView.push(maximizedImage)
    maximizedImage.imageSource = img.source
    maximizedImage.text = text
    maximizedImage.currentIndex = index
    maximizedImage.count = fileModel.count-1
    maximizedImage.setFocus = true
}
function changeCurrentIndex(index)
{
    var filePath = fileModel.get(index,ImageModel.SourceRole)
    var text = fileModel.get(index,ImageModel.FilePathRole)
    maximizedImage.imageSource = filePath
    maximizedImage.text = text
}
function makeViewChange()
{
    stackView.pop()
    switch(comboBox.currentIndex)
    {
    case 0:
    {
        stackView.push(listViewContainer)
        break
    }
    case 1:
    {
        stackView.push(gridViewContainer)
        break
    }
    case 2:
    {
        stackView.push(pathViewContainer)
        break
    }
    }
}
function setTheCurrentIndex(desiredIndex,currentIndex)
{
    if (desiredIndex!==currentIndex)
    {

        if (desiredIndex>currentIndex)
        {
            for (var i=currentIndex;i<desiredIndex;i++)
            {
                comboBox.incrementCurrentIndex()
            }
        }
        else
        {
            for (var i=currentIndex;i>desiredIndex;i--)
            {
                comboBox.decrementCurrentIndex()
            }
        }
    }
}
function decreaseCurrent()
{
    if (maximizedImage.currentIndex>0)
    {
        maximizedImage.currentIndex--
        changeCurrentIndex(maximizedImage.currentIndex)
    }
    else{
        makeViewChange()
    }
}
function increaseCurrent()
{
    if (maximizedImage.currentIndex<maximizedImage.count)
    {
        maximizedImage.currentIndex++
        changeCurrentIndex(maximizedImage.currentIndex)
    }
    else{
        makeViewChange()
    }
}

function setTheListView(){
    if (stackView.currentItem.objectName==="slideShowEffect")
    {
        stackView.pop();
        stackView.push(listViewContainer)
    }
    else{
        var index = comboBox.find('list')
        var currentIndex = comboBox.currentIndex
        Utilities.setTheCurrentIndex(index,currentIndex)
    }
}

function setTheGridView()
{
    if (stackView.currentItem.objectName==="slideShowEffect")
    {
        stackView.pop();
        stackView.push(gridViewContainer)
    }
    else{
        var index = comboBox.find('grid')
        var currentIndex = comboBox.currentIndex
        Utilities.setTheCurrentIndex(index,currentIndex)
    }
}

function setThePathView()
{
    if (stackView.currentItem.objectName==="slideShowEffect")
    {
        stackView.pop();
        stackView.push(pathViewContainer)

    }
    else{
        var index = comboBox.find('path')
        var currentIndex = comboBox.currentIndex
        Utilities.setTheCurrentIndex(index,currentIndex)
    }
}
function setTheSlideShowView()
{
    if (fileModel.count>=2)
    {
        stackView.pop();
        stackView.push(slideShowEffect)
    }
}
