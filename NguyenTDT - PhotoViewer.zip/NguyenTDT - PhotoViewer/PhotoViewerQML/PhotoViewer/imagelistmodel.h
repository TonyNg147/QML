#ifndef IMAGELISTMODEL_H
#define IMAGELISTMODEL_H

#include <QAbstractListModel>
#include "dataformodel.h"
class ImageListModel : public QAbstractListModel
{
    Q_OBJECT
    // Register these variables so that
    // they can be used and assigned in QML side
    Q_PROPERTY(DataForModel *data READ data WRITE setData)
    Q_PROPERTY(int count READ count WRITE setCount NOTIFY countChanged)
public:
    // declare enum type and register it to use in QML
    enum DataType{SourceRole=Qt::UserRole,FilePathRole};
    Q_ENUM(DataType)
    explicit ImageListModel(QObject *parent = nullptr);
    // Basic functionality:
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    // Editable:
    bool setData(const QModelIndex &index, const QVariant &value,
                 int role = Qt::EditRole) override;
    // override this function to set characteristics for our model
    Qt::ItemFlags flags(const QModelIndex& index) const override;
    DataForModel* data() const;
    void setData(DataForModel* data);
    // define our own roles
    virtual QHash<int, QByteArray> roleNames() const override;
    Q_INVOKABLE int count() const;
    Q_INVOKABLE QString get(int index,int role) const;
    void setCount(int newCount);

signals:
    // these functions will be called
    // so that QML side can catch those to do some works
    void makeViewChange();
    void countChanged();
public slots:
    // open dialog to choose Images
    void pickingFile();
    // append new Image item into our current model
    void appendPics(QString path);
    // this is paired with makeViewChanged()
    void emitMakeViewChange();
private:
    DataForModel* m_data;
    int m_count;
    QString test;
};

#endif // IMAGELISTMODEL_H
