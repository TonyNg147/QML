#ifndef VIEWCONTROLLER_H
#define VIEWCONTROLLER_H

#include <QObject>
#include <QComboBox>
#include <QTimer>
class ViewController : public QObject
{
    Q_OBJECT
    // By using Q_Property, this variable will be exposed in QML side so
    // we can assign the number of item we will handle with
    Q_PROPERTY(int count READ count WRITE setCount)
public:
    explicit ViewController(QObject *parent = nullptr);
    explicit ViewController(int duration,QObject *parent = nullptr);
    int count() const;
    void setCount(int newCount);

public slots:
    // start and stop the Timer
    void start();
    void stop();
    // Do logic business when Time is up
    void timeout();
signals:
    // this Signal will be emited in C++ side and be caught in QML side to do business logic
    void dueTime(int pre, int post);
private:
    QTimer* m_timer = nullptr;
    int m_duration;
    int m_count;
    int m_pre, m_post;
};

#endif // VIEWCONTROLLER_H
