#include "dataformodel.h"
#include <QDebug>
DataForModel::DataForModel(QObject *parent) : QObject(parent)
{

}
QVector<DataItem> DataForModel::items() const
{
    return m_item;
}

void DataForModel::removeItem(int index)
{
    //validate and implement the removal
    if (0<=index&&index<m_item.size())
    {
        emit preRemoveItem(index);
        m_item.remove(index);
        emit postRemoveItem();
    }
}

void DataForModel::appendItem(QString source, QString filePath)
{
    // do append new Item into our current DataSource
    // and alert the model about changes
    emit preAppendItem();
    DataItem item;
    item.source = source;
    item.filePath = filePath;
    m_item.append(item);
    emit postAppendItem();
}

bool DataForModel::setItemAt(int index, const DataItem& item)
{
    // validate the index
    if (index<0||index>=m_item.size())
    {
        return false;
    }
    // check whether or not the new Item is valid
    const DataItem& oldItem = m_item.at(index);
    if (oldItem.source == item.source&& oldItem.filePath == item.filePath)
    {
        return false;
    }
    m_item[index] =item;
    return true;
}
